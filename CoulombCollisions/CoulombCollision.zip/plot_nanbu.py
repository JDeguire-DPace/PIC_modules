import numpy as np
from matplotlib import pyplot as plt

plt.style.use('dark_background')
# Load data

data_7 = np.loadtxt('Coulomb_7.txt')
data_8 = np.loadtxt('Coulomb_8.txt')
data_9 = np.loadtxt('Coulomb_9.txt')


# Create subplots
fig, ax = plt.subplots(1, 2, figsize=(17, 5))

# Plot for temperature

ax[0].plot(data_7[:, 0], data_7[:, 1], color='#E6CCF5', linewidth=1)
ax[0].plot(data_7[:, 0], data_7[:, 2], color='#E6CCF5', linewidth=1)
ax[0].plot(data_8[:, 0], data_8[:, 1], color='#AAF0D1', linewidth=1)
ax[0].plot(data_8[:, 0], data_8[:, 2], color='#AAF0D1', linewidth=1)
ax[0].plot(data_9[:, 0], data_9[:, 1], color='#FFDAB9', linewidth=1)
ax[0].plot(data_9[:, 0], data_9[:, 2], color='#FFDAB9', linewidth=1)
ax[0].set_xlabel('time (s)')
ax[0].set_ylabel('$k_B T$ (eV)')
ax[0].set_xlim(0, 2e-5)

# Plot for velocity ratio
ax[1].plot(data_7[:, 0], data_7[:, 3], color='#E6CCF5', linewidth=1, label='$\\Delta t = 10^{-7}$ s')
ax[1].plot(data_7[:, 0], data_7[:, 4], color='#E6CCF5', linewidth=1)
ax[1].plot(data_8[:, 0], data_8[:, 3], color='#AAF0D1', linewidth=1, label='$\\Delta t = 10^{-8}$ s')
ax[1].plot(data_8[:, 0], data_8[:, 4], color='#AAF0D1', linewidth=1)
ax[1].plot(data_9[:, 0], data_9[:, 3], color='#FFDAB9', linewidth=1, label='$\\Delta t = 10^{-9}$ s')
ax[1].plot(data_9[:, 0], data_9[:, 4], color='#FFDAB9', linewidth=1)
ax[1].set_xlabel('time (s)')
ax[1].set_ylabel('$V/V_{0_{elec}}$')
ax[1].set_xlim(0, 2.e-5)

# Collect labels from both subplots
handles, labels = [], []
for a in ax:
    h, l = a.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)

# Adjust layout first
plt.tight_layout()

fig.legend(handles, labels, fontsize=15, loc='center right')

# Adjust margins to make space for the legend
plt.subplots_adjust(right=0.85)  # Increase if necessary
# Show the plot
plt.show()
